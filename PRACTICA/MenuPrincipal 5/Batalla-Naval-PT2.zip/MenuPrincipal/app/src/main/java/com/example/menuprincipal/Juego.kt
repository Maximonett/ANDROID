package com.example.menuprincipal

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import kotlin.random.Random

class Juego : AppCompatActivity() {
    private lateinit var barraHerramientas: Toolbar
    private lateinit var tablero: Array<Button>
    private lateinit var grillaTablero: GridLayout
    private lateinit var textoMovimientos: TextView
    private lateinit var textoAciertos: TextView
    private lateinit var textoRestantes: TextView
    private lateinit var mensajefinjuego : String
    private lateinit var nombre: String

    private var colorlocetas: Int = 0
    private var colorAgua: Int = 0
    private var colorBordo: Int = 0


    private var tamañoTablero: Int = 0
    private var totalCeldas: Int = 0

    private lateinit var hayBarco: BooleanArray

    private var totalBarcos = 0
    private var movimientos = 0
    private var aciertos = 0
    private var aciertosAgua = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_juego)

        nombre = intent.getStringExtra("Nombre") ?: "No definodo"
        tamañoTablero = intent.getIntExtra("Tamaño", 0)
        totalCeldas = tamañoTablero * tamañoTablero

        barraHerramientas = findViewById(R.id.barraHerramientas)
        grillaTablero = findViewById(R.id.boardGrid)
        textoMovimientos = findViewById(R.id.movementsText)
        textoAciertos = findViewById(R.id.hitsText)
        textoRestantes = findViewById(R.id.remainingText)

        textoMovimientos.text =   getString(R.string.movimientos,movimientos)
        textoAciertos.text =   getString(R.string.aciertos, aciertos)
        textoRestantes.text = getString(R.string.barcos_restantes, (totalBarcos - aciertos))


        textoRestantes.setTextColor(Color.BLACK)
        colorlocetas = ContextCompat.getColor(this, R.color.gris_oscuro)
        colorAgua = ContextCompat.getColor(this, R.color.celeste_francia)
        colorBordo = ContextCompat.getColor(this, R.color.bordo_profundo)


        configurarTablero()
        setSupportActionBar(barraHerramientas)


        if (savedInstanceState != null) {
                // Restaurar estado guardado
                movimientos = savedInstanceState.getInt("movimientos", 0)
                aciertos = savedInstanceState.getInt("aciertos", 0)
                totalBarcos = savedInstanceState.getInt("totalBarcos", 0)
                hayBarco = savedInstanceState.getBooleanArray("hayBarco") ?: BooleanArray(totalCeldas) { false }
                restaurarEstadoTablero(savedInstanceState)
                actualizarEstadisticas()
            } else {
                IniciarJuego()
            }
    }

    // Guardar estado antes de que destruya la Activity
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        outState.putInt("movimientos", movimientos)
        outState.putInt("aciertos", aciertos)
        outState.putInt("totalBarcos", totalBarcos)
        outState.putBooleanArray("hayBarco", hayBarco)

        for (i in tablero.indices) {
            outState.putBoolean("boton_enabled_$i", tablero[i].isEnabled)
            outState.putCharSequence("boton_text_$i", tablero[i].text)
            val color = (tablero[i].background as? ColorDrawable)?.color ?: Color.LTGRAY
            outState.putInt("boton_color_$i", color)
        }
    }

    private fun restaurarEstadoTablero(savedInstanceState: Bundle) {
        for (i in tablero.indices) {
            tablero[i].isEnabled = savedInstanceState.getBoolean("boton_enabled_$i", true)
            val color = savedInstanceState.getInt("boton_color_$i", Color.LTGRAY)
            tablero[i].setBackgroundColor(color)
        }
    }


    private fun configurarTablero() {
        tablero = Array(totalCeldas) { Button(this) }
        grillaTablero.removeAllViews()
        grillaTablero.columnCount = tamañoTablero

        for (i in tablero.indices) {
            val celda = Button(this)
            celda.layoutParams = GridLayout.LayoutParams().apply {
                width = 40
                height = 40
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            celda.setBackgroundColor(colorlocetas)
            celda.setOnClickListener { alTocarCelda(i) }
            tablero[i] = celda
            grillaTablero.addView(celda)
        }
    }

    private fun IniciarJuego() {

        movimientos = 0
        aciertos = 0
        totalBarcos = (10..15).random()
        hayBarco = BooleanArray(totalCeldas) { false }

        val posicionesBarcos = mutableSetOf<Int>()
        while (posicionesBarcos.size < totalBarcos) {
            posicionesBarcos.add(Random.nextInt(0, totalCeldas))
        }

        for (pos in posicionesBarcos) {
            hayBarco[pos] = true
        }

        actualizarEstadisticas()

        for (i in tablero.indices) {
            tablero[i].isEnabled = true
            tablero[i].text = " "
            tablero[i].textSize = 10f
            tablero[i].setBackgroundColor(Color.DKGRAY)
        }
    }

    private fun alTocarCelda(indice: Int) {
        movimientos++

        tablero[indice].isEnabled = false

        // Lógica para marcar acierto si hay barco
        if (hayBarco[indice]) {
            aciertos++
            tablero[indice].setBackgroundColor(colorBordo)
            tablero[indice].text = getString(R.string.barco)
            tablero[indice].setTextColor(Color.WHITE)

        } else {
            tablero[indice].setBackgroundColor(colorAgua)
            tablero[indice].text = getString(R.string.agua)
            tablero[indice].setTextColor(Color.WHITE)

        }

        actualizarEstadisticas()

        if (aciertos == totalBarcos) {
            mostrarFinDelJuego()
        }
    }

    private fun actualizarEstadisticas() {
        textoMovimientos.text =   getString(R.string.movimientos,movimientos)
        textoAciertos.text =   getString(R.string.aciertos, aciertos)
        textoRestantes.text = getString(R.string.barcos_restantes, (totalBarcos - aciertos))
        textoRestantes.setTextColor(Color.BLACK)
    }

    private fun mostrarFinDelJuego() {

        aciertosAgua = movimientos - aciertos
        for (i in tablero.indices) {
            tablero[i].isEnabled = false
        }
        mensajefinjuego = getString(R.string.mensaje_fin_juego, nombre, aciertos, aciertosAgua)
        Toast.makeText(this, mensajefinjuego, Toast.LENGTH_LONG).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_pal, menu)
        return true
    }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            return when (item.itemId) {
                R.id.menuNuevo -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.menuAyuda -> {
                    val intent = Intent(this, Ayuda::class.java)
                    startActivity(intent)
                    true
                }
                R.id.menuSalir -> {
                    finishAffinity() // Cierra la app
                    true
                }
                else -> super.onOptionsItemSelected(item)
        }
    }
}
