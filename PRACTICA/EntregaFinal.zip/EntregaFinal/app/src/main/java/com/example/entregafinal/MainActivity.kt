package com.example.entregafinal

import com.example.entregafinal.R
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var tablero: Array<Button>
    private lateinit var grillaTablero: GridLayout
    private lateinit var textoMovimientos: TextView
    private lateinit var textoAciertos: TextView
    private lateinit var textoRestantes: TextView
    private lateinit var botonReiniciar: Button

    private val tamañoTablero = 6
    private val totalCeldas = tamañoTablero * tamañoTablero

    private lateinit var hayBarco: BooleanArray

    private var totalBarcos = 0
    private var movimientos = 0
    private var aciertos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grillaTablero = findViewById(R.id.boardGrid)
        textoMovimientos = findViewById(R.id.movementsText)
        textoAciertos = findViewById(R.id.hitsText)
        textoRestantes = findViewById(R.id.remainingText)
        botonReiniciar = findViewById(R.id.resetButton)

        botonReiniciar.setOnClickListener { reiniciarJuego() }

        configurarTablero()
        reiniciarJuego()
    }

    private fun configurarTablero() {
        tablero = Array(totalCeldas) { Button(this) }
        grillaTablero.removeAllViews()
        grillaTablero.columnCount = tamañoTablero

        for (i in tablero.indices) {
            val celda = Button(this)
            celda.layoutParams = GridLayout.LayoutParams().apply {
                width = 60
                height = 60
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            celda.setBackgroundColor(Color.LTGRAY)
            celda.setOnClickListener { alTocarCelda(i) }
            tablero[i] = celda
            grillaTablero.addView(celda)
        }
    }

    private fun reiniciarJuego() {
        movimientos = 0
        aciertos = 0
        totalBarcos = (10..15).random()
        hayBarco = BooleanArray(totalCeldas) { false }

        val posicionesBarcos = mutableSetOf<Int>()
        while (posicionesBarcos.size < totalBarcos) {
            posicionesBarcos.add(Random.nextInt(0, totalCeldas))
        }

        for (pos in posicionesBarcos) {
            hayBarco[pos] = true
        }

        actualizarEstadisticas()

        for (i in tablero.indices) {
            tablero[i].isEnabled = true
            tablero[i].text = "A jugar"
            tablero[i].setBackgroundColor(Color.LTGRAY)
        }
    }

    private fun alTocarCelda(indice: Int) {
        movimientos++
        tablero[indice].isEnabled = false
        if (hayBarco[indice]) {
            aciertos++
            tablero[indice].setBackgroundResource(R.drawable.barco)
        } else {
            tablero[indice].setBackgroundResource(R.drawable.agua)
        }

        actualizarEstadisticas()

        if (aciertos == totalBarcos) {
            mostrarFinDelJuego()
        }
    }

    private fun actualizarEstadisticas() {
        textoMovimientos.text = "Movimientos: $movimientos"
        textoAciertos.text = "Aciertos: $aciertos"
        textoRestantes.text = "Barcos restantes: ${totalBarcos - aciertos}"
        textoRestantes.setTextColor(Color.BLACK)
    }

    private fun mostrarFinDelJuego() {
        for (i in tablero.indices) {
            tablero[i].isEnabled = false
        }
        if (aciertos == totalBarcos) {
            textoRestantes.text = "¡Ganaste!"
            textoRestantes.setTextColor(Color.GREEN)
        }
    }
}